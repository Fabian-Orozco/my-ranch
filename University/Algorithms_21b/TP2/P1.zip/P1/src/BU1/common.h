#ifndef COMMON_H
#define COMMON_H

#include <iostream>
using namespace std;

#endif  // COMMON_H