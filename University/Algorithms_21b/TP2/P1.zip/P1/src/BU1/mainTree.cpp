#include <random>
#include <windows.h>
#include "bstree.h"
#include "common.h"
#include <chrono>

void f_testTree( tree<int>* );      // prueba un arbol de 10 nodos
void f_fillTree_test( tree<int>* ); // llena con rango -50 a 50


void f_fillTree_rand( tree<int>* ); // llena el arbol con 1M de nums aleatorios
void f_treeData( tree<int>* ); // imprime los datos del arbol

int f_search_rand_rec( tree<int>* ); // busca recursivamente 1M
int f_search_rand_it( tree<int>* ); // busca iterativamente 1M

int main() {
  SetConsoleOutputCP(CP_UTF8);
  cout << "\n-inicia\n" << endl;

  tree<int>* myTree;
  myTree = new tree<int>();

  // f_testTree(myTree);
  // myTree->f_forma(myTree->getRoot());

  // seccion 2.2) paso 2
  // f_testTree(myTree);
  f_fillTree_rand(myTree);
  // f_treeData(myTree);
  
  int qtyBusquedas = f_search_rand_rec(myTree);
  cout << "Qty de busquedas en 10 segundos [tree]" << endl; 
  cout << "Aleatoria[rec]:  " << qtyBusquedas << endl;
  qtyBusquedas = f_search_rand_it(myTree);
  cout << "Aleatoria[it]:   " << qtyBusquedas << endl;
  
  delete myTree;

  myTree = new tree<int>();
  myTree->f_fillTree_sec(1000000); // llena de 0 a 999999
  // f_treeData(myTree);

  qtyBusquedas = f_search_rand_rec(myTree);
  cout << "Secuencial[rec]: " << qtyBusquedas << endl;
  qtyBusquedas = f_search_rand_it(myTree);
  cout << "Secuencial[it]:  " << qtyBusquedas << endl;
  
  delete myTree;
  cout << "\n-termina" << endl;
  return 0;
}

// ################################################################

void f_fillTree_test(tree<int>* tree){
  cout << "inserción: ";
  random_device dev;
  mt19937 rng(dev());
  for (int i = 0; i < 5; ++i) {
    uniform_int_distribution<mt19937::result_type> dist6(-50,50);
    int num = dist6(rng);
    cout << num << " ";
    node<int> * nodo = new node<int>(num);
    tree->treeInsert(nodo);
  }
  cout << endl;
}

// ################################################################

void f_fillTree_rand(tree<int>* tree){
  random_device dev;
  mt19937 rng(dev());
  for (int i = 0; i < 1000000; ++i) {
    uniform_int_distribution<mt19937::result_type> dist6(0,2000000);
    node<int> * nodo = new node<int>(dist6(rng));
    tree->treeInsert(nodo);
  }
}
// ################################################################


// ################################################################
void f_testTree(tree<int>* myTree) {
  f_fillTree_test(myTree);
  // myTree->treeInsert( new node<int>(0) );
  node<int>* myTreeRoot = myTree->getRoot();

  cout << "recInOrder: "; myTree->inorderTreeWalk(myTreeRoot);
  cout << endl;
  
  int numBuscado = 6;
  if (myTree->treeSearch(numBuscado) ){
    cout << numBuscado << " ha sido encontrado [rec]\n";
  } else { cout << numBuscado << " no ha sido encontrado [rec]\n";}

  if (myTree->iterativeTreeSearch(numBuscado) ){
    cout << numBuscado << " ha sido encontrado [it]\n";
  } else { cout << numBuscado << " no ha sido encontrado [it]\n";}

  f_treeData(myTree);
  
  // pass the root node of your binary tree
  // myTree->printBT(myTree->getRoot());
}
// ################################################################

void f_treeData(tree<int>* myTree) {
  node<int>* myTreeRoot = myTree->getRoot();
  cout << "\nrootKey: " << myTreeRoot->key << "\n";
  cout << "treeMaximum: " << (myTree->treeMaximum())->key << "\n";
  cout << "treeMinimum: " << (myTree->treeMinimum())->key << "\n";
  
  cout << "derecha de root: ";
  if (myTreeRoot->right){cout << myTreeRoot->right->key << "\n";}
  else {cout << "nullptr\n";}

  cout << "izquierda de root: ";
  if (myTreeRoot->left) {cout<< myTreeRoot->left->key << "\n";}
  else {cout << "nullptr\n";}

  cout << "Sucesor de " << myTreeRoot->key << ": " \
    << (myTree->treeSuccessor(myTreeRoot))->key << "\n";
  cout << "rootKey: " << myTreeRoot->key << "\n";
}

// ################################################################

int f_search_rand_rec(tree<int>* myTree){
  // cout << "\n\nPruebas\n";
  auto start = chrono::system_clock::now();
  random_device r;
  mt19937 eng(0);
  int QtyBusquedas = 0;
  while (true) {
    uniform_int_distribution<mt19937::result_type> dist6(0,2000000);
    int num_buscado = dist6(r);
    // cout << num_buscado << " ";
    myTree->treeSearch(num_buscado);
    auto end = chrono::system_clock::now();
    auto time_elapsed = chrono::duration_cast<chrono::seconds>(end - start).count();
    ++QtyBusquedas;
    if (time_elapsed == 10) return QtyBusquedas;
  }
  return 0;
}

int f_search_rand_it(tree<int>* myTree){
  // cout << "\n\nPruebas\n";
  auto start = chrono::system_clock::now();
  random_device r;
  mt19937 eng(0);
  int QtyBusquedas = 0;
  while (true) {
    uniform_int_distribution<mt19937::result_type> dist6(0,2000000);
    int num_buscado = dist6(r);
    // cout << num_buscado << " ";
    myTree->iterativeTreeSearch(num_buscado);
    auto end = chrono::system_clock::now();
    auto time_elapsed = chrono::duration_cast<chrono::seconds>(end - start).count();
    ++QtyBusquedas;
    if (time_elapsed == 10) return QtyBusquedas;
  }
  return 0;
}
